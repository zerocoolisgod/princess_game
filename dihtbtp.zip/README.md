# princess_game

Controls
  movement: w,a,s,d
  action1: j
  jump: k
  start: space
  select: tab
  quit: q / esc (to be changed or removed later)
  debug: f1
  fullscreen: f11
  reset: f12

Controls can be remapped by pressing select at the title screen.

Level select is tuned on at the title screen to help with level testing.
Will be removed later or kept as a "cheat code".